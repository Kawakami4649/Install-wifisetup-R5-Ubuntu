sudo tar xfvz setconf.tar.gz -C /
sudo tar xfvz network-config.tar.gz -C /
sudo apt install hostapd
sudo apt install dnsmasq

sudo systemctl unmask hostapd
sudo systemctl enable hostapd
# sudo systemctl start hostapd
# sudo systemctl restart dnsmasq
sudo systemctl enable dnsmasq
# sudo netplan apply
sudo sysctl -p
sudo iptables -t nat -A POSTROUTING -s 192.168.10.0/24 -o eth0 -j MASQUERADE
sudo apt install iptables-persistent
sudo iptables-save | sudo tee /etc/iptables/rules.v4

sudo cp --preserve=timestamps redirect-enabled.conf /etc/apache2/conf-enabled/
sudo cp --preserve=timestamps ap_config_02.cgi /usr/lib/cgi-bin/ap_config.cgi
sudo cp --preserve=timestamps set_time.cgi /usr/lib/cgi-bin/
sudo mkdir /var/www/html/css/
sudo cp --preserve=timestamps ap_config_login.css /var/www/html/css/
sudo cp --preserve=timestamps ap_config_system_01.css /var/www/html/css/ap_config_system.css
sudo cp --preserve=timestamps ap_config.ini /usr/lib/cgi-bin/
sudo mkdir /var/www/html/img/
sudo cp --preserve=timestamps logo-mini.gif /var/www/html/img/
sudo cp --preserve=timestamps post-icon.gif /var/www/html/img/
sudo cp --preserve=timestamps network-icon.gif /var/www/html/img/
sudo cp --preserve=timestamps chat-icon.gif /var/www/html/img/
sudo cp --preserve=timestamps sysinfo-icon.gif /var/www/html/img/
sudo cp --preserve=timestamps '.htaccess' /var/www/html/
# sudo systemctl restart apache2
sudo cp --preserve=timestamps 99-usb-autosuspend.rules /etc/udev/rules.d/
sudo cp --preserve=timestamps update_wifi_config.sh /usr/local/bin/
sudo cp --preserve=timestamps rc.local /etc/
sudo cp --preserve=timestamps rc-local.service /etc/systemd/system/
sudo systemctl enable rc-local
# sudo systemctl start rc-local
echo '192.168.10.1 chat.local' | sudo tee -a /etc/hosts > /dev/null
sudo cp --preserve=timestamps add_hosts.sh /usr/local/bin/
# sudo cp --preserve=timestamps named.conf.options /etc/bind/
# sudo systemctl restart bind9

