#!/bin/sh

echo "Content-type: text/html"
echo ""

CONFIG_FILE="./ap_config.ini"
STORED_PASSWORD=$(grep '^admin_password=' "$CONFIG_FILE" | cut -d '=' -f2)

#urldecode() {
#  echo "$1" | sed -e 's/+/ /g' -e 's/%\([0-9A-Fa-f][0-9A-Fa-f]\)/\\\\x\1/g' | xargs printf "%b"
#}
urldecode() {
  echo "$1" | sed 's/+/ /g' | awk '
    {
      while (match($0, /%[0-9A-Fa-f]{2}/)) {
        hex = substr($0, RSTART+1, 2)
        char = sprintf("%c", strtonum("0x" hex))
        $0 = substr($0, 1, RSTART-1) char substr($0, RSTART+3)
      }
      print
    }
  '
}

read POST_DATA
#echo "<pre>RAW=$POST_DATA</pre>"
POST_DATA=$(urldecode "$POST_DATA")
#echo "<pre>DEC=$POST_DATA</pre>"

ADMIN_PASSWORD=$(echo "$POST_DATA" | sed -n 's/.*admin_pw=\([^&]*\).*/\1/p')
INPUT_PASSWORD=$(echo "$POST_DATA" | sed -n 's/.*auth=\([^&]*\).*/\1/p')
if [ -z "$ADMIN_PASSWORD" ]; then
  ADMIN_PASSWORD=$STORED_PASSWORD
else
  STORED_PASSWORD=$ADMIN_PASSWORD
  INPUT_PASSWORD=$ADMIN_PASSWORD
fi
# パラメータ抽出
#APLAN_IF="wlx782051153786"
APLAN_IF=$(ip a | grep wlx |  awk '{print $2}' | cut -d ':' -f1 | head -n 1)
if [ -z "$APLAN_IF" ]; then
  APLAN_IF="wlan0"
fi
WAN_IF="eth0"
WLAN_IF="wlan0"
SSID=$(echo "$POST_DATA" | sed -n 's/.*ap_ssid=\([^&]*\).*/\1/p' | sed 's/+/ /g; s/%20/ /g')
PSK=$(echo "$POST_DATA" | sed -n 's/.*ap_psk=\([^&]*\).*/\1/p')

AP_HW_MODE=$(echo "$POST_DATA" | sed -n 's/.*ap_hw_mode=\([^&]*\).*/\1/p')
AP_CHANNEL=$(echo "$POST_DATA" | sed -n 's/.*ap_channel=\([^&]*\).*/\1/p')

CURRENT_AP_CHANNEL=$(iw dev "$APLAN_IF" info | grep channel | awk '{print $2}' | head -n 1)
CURRENT_AP_FREQ=$(iw dev "$APLAN_IF" info | grep channel | awk '{print $3}' | cut -c2-)
CURRENT_AP_FREQ_PREFIX=$(echo "$CURRENT_AP_FREQ" | cut -c1-2)

if [ -z "$AP_HW_MODE" ]; then
  if [ "$CURRENT_AP_FREQ_PREFIX" = "24" ]; then
    AP_HW_MODE='g'
  else
    AP_HW_MODE='a'
  fi
fi
#echo "CURRENT_AP_CHANNEL: $CURRENT_AP_CHANNEL"

AP_IP=$(echo "$POST_DATA" | sed -n 's/.*ap_ip=\([^&]*\).*/\1/p')
RANGE_START=$(echo "$POST_DATA" | sed -n 's/.*range_start=\([^&]*\).*/\1/p')
RANGE_END=$(echo "$POST_DATA" | sed -n 's/.*range_end=\([^&]*\).*/\1/p')
LEASE_TIME=$(echo "$POST_DATA" | sed -n 's/.*lease_time=\([^&]*\).*/\1/p')
SYS_ACTION=$(echo "$POST_DATA" | sed -n 's/.*sys_action=\([^&]*\).*/\1/p')

AP_DHCP_ENABLED=$(echo "$POST_DATA" | sed -n 's/.*ap_dhcp_enabled=\([^&]*\).*/\1/p')
WAN_DNS=$(echo "$POST_DATA" | sed -n 's/.*wan_dns=\([^&]*\).*/\1/p' | sed 's/+/ /g; s/%20/ /g')
WLAN_DNS=$(echo "$POST_DATA" | sed -n 's/.*wlan_dns=\([^&]*\).*/\1/p' | sed 's/+/ /g; s/%20/ /g')

DISPLAY_SSH_ENABLED=$(sudo systemctl status ssh | grep Active | awk '{print $2}' | head -n 1)
SSH_ENABLED=$(echo "$POST_DATA" | tr '&' '\n' | grep '^ssh_enabled=' | cut -d '=' -f2)

DISPLAY_NAMED_ENABLED=$(sudo systemctl status bind9 | grep Active | awk '{print $2}' | head -n 1)
NAMED_ENABLED=$(echo "$POST_DATA" | tr '&' '\n' | grep '^named_enabled=' | cut -d '=' -f2)

DISPLAY_AP_DHCP_ENABLED=$(sudo systemctl status dnsmasq | grep Active | awk '{print $2}' | head -n 1)
DISPLAY_WAN_DNS=$(resolvectl status | sed -n "/(${WAN_IF})/,/^Link /p" | awk '/DNS Servers:/ {for (i=3; i<=NF; i++) printf "%s ", $i; print ""}')
DISPLAY_WLAN_DNS=$(resolvectl status | sed -n "/(${WLAN_IF})/,/^Link /p" | awk '/DNS Servers:/ {for (i=3; i<=NF; i++) printf "%s ", $i; print ""}')
#echo "<pre>DISPLAY_WAN_DNS==$DISPLAY_WAN_DNS=</pre>"
#echo "<pre>DISPLAY_WLAN_DNS==$DISPLAY_WLAN_DNS=</pre>"

DISPLAY_APLAN_IF=$(ip route | grep default | grep "$APLAN_IF" | awk '{print $5}' | head -n 1)
DISPLAY_APLAN_ROUTE=$(ip route | grep default | grep "$APLAN_IF" | awk '{print $3}' | head -n 1)

DISPLAY_WAN_IF=$(ip route | grep default | grep "$WAN_IF" | awk '{print $5}' | head -n 1)
DISPLAY_WAN_ROUTE=$(ip route | grep default | grep "$WAN_IF" | awk '{print $3}' | head -n 1)
	
DISPLAY_WLAN_IF=$(ip route | grep "$WLAN_IF" | awk '{print $5}' | head -n 2 | sed -n '2{p;q}')
DISPLAY_WLAN_ROUTE=$(ip route | grep default | grep "$WLAN_IF" | awk '{print $3}')

WAN_DHCP_ENABLED=$(echo "$POST_DATA" | tr '&' '\n' | grep '^wan_dhcp_enabled=' | cut -d '=' -f2)
#echo "<pre>$(echo "$POST_DATA" | tr '&' '\n' | grep '^wan_ip=')</pre>"
WAN_IP=$(echo "$POST_DATA" | tr '&' '\n' | grep '^wan_ip=' | cut -d '=' -f2)
#echo "<pre>WAN_IP=$WAN_IP</pre>"
WAN_IF=${WAN_IF:-$DISPLAY_WAN_IF}
WAN_ROUTE=$(echo "$POST_DATA" | tr '&' '\n' | grep '^wan_route=' | cut -d '=' -f2)
CURRENT_WAN_DHCP_ENABLED=$(ip route | grep default | grep "$WAN_IF" | awk '/proto/ {for(i=1;i<=NF;i++) if($i=="proto") print ($(i+1)=="dhcp"?"yes":"no")}')
CURRENT_WAN_IP=$(ip addr show "$WAN_IF" | grep 'inet ' | awk '{print $2}' | cut -d '/' -f1)
#echo "<pre>CURRENT_WAN_IP=$CURRENT_WAN_IP</pre>"
WLAN_DHCP_ENABLED=$(echo "$POST_DATA" | tr '&' '\n' | grep '^wlan_dhcp_enabled=' | cut -d '=' -f2)
# echo "$POST_DATA"
# echo "WLAN_DHCP_ENABLED=$WLAN_DHCP_ENABLED"
WLAN_IP=$(echo "$POST_DATA" | tr '&' '\n' | grep '^wlan_ip=' | cut -d '=' -f2)
WLAN_IF=${WLAN_IF:-$DISPLAY_WLAN_IF}
WLAN_SSID=$(echo "$POST_DATA" | sed -n 's/.*wlan_ssid=\([^&]*\).*/\1/p')
#echo "WLAN_SSID=[$WLAN_SSID]</pre>"
WLAN_PASSWORD=$(echo "$POST_DATA" | sed -n 's/.*wlan_password=\([^&]*\).*/\1/p')
if [ -n "$DISPLAY_WLAN_IF" ]; then
# DISPLAY_WLAN_IF=$(ip route | grep "$WLAN_IF" | awk '{print $5}' | head -n 2 | sed -n '2{p;q}')
# DISPLAY_WLAN_ROUTE=$(ip route | grep default | grep "$WLAN_IF" | awk '{print $3}')
CURRENT_WLAN_DHCP_ENABLED=$(ip route | grep default | grep "$WLAN_IF" | awk '/proto/ {for(i=1;i<=NF;i++) if($i=="proto") print ($(i+1)=="dhcp"?"yes":"no")}')
CURRENT_WLAN_IP=$(ip addr show "$WLAN_IF" | grep 'inet ' | awk '{print $2}' | cut -d '/' -f1)
else
DISPLAY_WLAN_IF=""
DISPLAY_WLAN_ROUTE=""
CURRENT_WLAN_DHCP_ENABLED="no"
CURRENT_WLAN_IP=""
fi

AP_NAT_ENABLED=$(echo "$POST_DATA" | tr '&' '\n' | grep '^ap_nat_enabled=' | cut -d '=' -f2)
if [ -z "$AP_NAT_ENABLED" ]; then
    if ! [ -z "$(sudo iptables -t nat -L -n -v | grep MASQUERADE | head -n 1)" ]; then
        AP_NAT_ENABLED="yes"
    fi
fi

# サブネットマスクをCIDRから変換（例: 24 → 255.255.255.0）
netmask_to_cidr() {
  IFS=. read -r i1 i2 i3 i4 <<EOF
$1
EOF
  bin=$(printf "%08d%08d%08d%08d\n" \
    "$(echo "obase=2;$i1" | bc)" \
    "$(echo "obase=2;$i2" | bc)" \
    "$(echo "obase=2;$i3" | bc)" \
    "$(echo "obase=2;$i4" | bc)")
  echo "$bin" | tr -cd '1' | wc -c
}

cidr_to_netmask() {
  case "$1" in
    8) echo "255.0.0.0" ;;
    16) echo "255.255.0.0" ;;
    24) echo "255.255.255.0" ;;
    25) echo "255.255.255.128" ;;
    26) echo "255.255.255.192" ;;
    27) echo "255.255.255.224" ;;
    28) echo "255.255.255.240" ;;
    29) echo "255.255.255.248" ;;
    30) echo "255.255.255.252" ;;
    31) echo "255.255.255.254" ;;
    32) echo "255.255.255.255" ;;
    *) echo "255.255.255.0" ;;  # fallback
  esac
}


AP_CIDR_MASK=$(ip addr show "$APLAN_IF" | grep 'inet ' | awk '{print $2}' | cut -d '/' -f2 | head -n1)
CURRENT_APLAN_NETMASK=$(cidr_to_netmask "$AP_CIDR_MASK")
APLAN_NETMASK=$(echo "$POST_DATA" | sed -n 's/.*aplan_netmask=\([^&]*\).*/\1/p')
# echo "APLAN_NETMASK=[$APLAN_NETMASK]"
if [ -z "$APLAN_NETMASK" ]; then
  AP_CIDR_MASK=$(netmask_to_cidr ip addr show "$APLAN_IF" | grep 'inet ' | awk '{print $2}' | cut -d '/' -f2 | head -n1)
  APLAN_NETMASK=$(cidr_to_netmask "$AP_CIDR_MASK")
else
  AP_CIDR_MASK=$(netmask_to_cidr "$APLAN_NETMASK")
fi
# echo "AP_CIDR_MASK=[$AP_CIDR_MASK]"
	  
CIDR_MASK=$(ip addr show "$WAN_IF" | grep 'inet ' | awk '{print $2}' | cut -d '/' -f2 | head -n1)
CURRENT_WAN_NETMASK=$(cidr_to_netmask "$CIDR_MASK")
WAN_NETMASK=$(echo "$POST_DATA" | sed -n 's/.*wan_netmask=\([^&]*\).*/\1/p')
if [ -z "$WAN_NETMASK" ]; then
  CIDR_MASK=$(ip addr show "$WAN_IF" | grep 'inet ' | awk '{print $2}' | cut -d '/' -f2 | head -n1)
  if [ -z "$CIDR_MASK" ]; then
    CIDR_MASK=24
  fi
  WAN_NETMASK=$(cidr_to_netmask "$CIDR_MASK")
else
  ETH0_CIDR=$(netmask_to_cidr "$WAN_NETMASK")
fi
#echo "<pre>ETH0_CIDR=$ETH0_CIDR</pre>"
WLAN_CIDR_MASK=$(ip addr show "$WLAN_IF" | grep 'inet ' | awk '{print $2}' | cut -d '/' -f2 | head -n1)
CURRENT_WAN_NETMASK=$(cidr_to_netmask "$WLAN_CIDR_MASK")
WLAN_NETMASK=$(echo "$POST_DATA" | sed -n 's/.*wlan_netmask=\([^&]*\).*/\1/p')
if [ -z "$WLAN_NETMASK" ]; then
  WLAN_CIDR_MASK=$(ip addr show "$WLAN_IF" | grep 'inet ' | awk '{print $2}' | cut -d '/' -f2 | head -n1)
  if [ -z "$WLAN_CIDR_MASK" ]; then
    WLAN_CIDR_MASK=24
  fi
  WLAN_NETMASK=$(cidr_to_netmask "$WLAN_CIDR_MASK")
else
  WLAN_CIDR=$(netmask_to_cidr "$WLAN_NETMASK")
fi

# echo "<pre>POST_DATA=$POST_DATA\nWAN_NETMASK=$WAN_NETMASK\nCURRENT_WAN_NETMASK=$CURRENT_WAN_NETMASK</pre>"
# echo "<pre>WAN_IP=$WAN_IP</pre>"

# 認証
if [ -z "$INPUT_PASSWORD" ]; then
  echo "<html><head><meta charset=UTF-8 />"
  echo "<script>"
  echo "  function toggleVisibility(className) {"
  echo "      var x = document.getElementById(className);"
  echo "      if (x.style.display === 'none') {"
  echo "          x.style.display = 'block';"
  echo "      } else {"
  echo "          x.style.display = 'none';"
  echo "      }"
  echo "  }"
  echo "</script>"
  echo "  <meta name='viewport' content='width=device-width, initial-scale=1.0'>"
  echo "<link rel='stylesheet' href='/css/ap_config_login.css'>"
  echo "</head><body>"
  echo "<main class='container'>"
  echo "  <div class='login-card'>"
  echo "    <h1>システム設定</h1>"
  echo "    <p>パスワードを入力してください。</p>"
  echo "    <form method='post'>"
  echo "      <input type='password' name='auth' placeholder='パスワード'>"
  echo "      <button type='submit' name='login'>ログイン</button>"
  echo "    </form>"
  echo "    <footer>"
  echo "      &copy; 2026 e-POST Inc. All rights reserved."
  echo "    </footer>"
  echo "  </div>"
  echo "<div class='login-card'>"
  echo "    <h1>チャットユーザ作成</h1>"
  echo "    <p><br/></p>"
  echo "<a href=/autouser/><img src=/img/chat-icon.gif title='チャットユーザ作成' width=128></a>"
  echo "    <footer>"
  echo "<br/>"
  echo "    </footer>"
  echo "  </div>"
  echo "  <div class='login-card'>"
  echo "    <h1>メールサーバ詳細設定</h1>"
  echo "    <p><br/></p>"
  echo "<a href=/epms/><img src=/img/post-icon.gif title='メールサーバ詳細設定' width=128></a>"
  echo "    <footer>"
  echo "<br/>"
  echo "    </footer>"
  echo "  </div>"
  echo "  <div class='login-card2'>"
  echo "    <center><h1>システム情報</h1></center>"
  echo "    <p><br/></p>"
  echo "<center><img src=/img/sysinfo-icon.gif title='システム情報' width=128 border=0 onclick=toggleVisibility('msg')></center><p id=msg style=display:none;>"
echo "<b>Bord:</b><br/>"
echo "$(cat /proc/device-tree/model)<br/>"
echo "<b>OS:</b><br/>"
echo "$(lsb_release -a)<br/>"
echo "<b>MEM:</b><br/>"
echo "$(df)<br/>"
echo "<b>Web Service:</b><br/>"
echo "$(ps ax | grep apache | head -n 4)<br/>"
echo "<b>Mail Service:</b><br/>"
echo "$(ps ax | grep epst | head -n 4)<br/>"
echo "<b>Network:</b><br/>"
echo "$(ip a show)<br/>"
echo "<b>Routing:</b><br/>"
echo "$(ip route)<br/>"
echo "<b>NAT:</b><br/>"
echo "$(sudo iptables -t nat -L -n -v)<br/>"
echo "<b>Pwoer throttled:</b><br/>"
echo "$(sudo vcgencmd get_throttled)<br/>"
echo "<b>CPU Temperature:</b><br/>"
echo "$(($(cat /sys/class/thermal/thermal_zone0/temp)/1000))°C<br/></p>"
  echo "    <footer>"
  echo "<br/>"
  echo "    </footer>"
  echo "  </div>"
  echo "</main>"
  echo "</body></html>"
  exit 0
fi

if [ "$INPUT_PASSWORD" != "$STORED_PASSWORD" ]; then
  echo "<html><head><meta charset=UTF-8 />"
  echo "<script>"
  echo "  function toggleVisibility(className) {"
  echo "      var x = document.getElementById(className);"
  echo "      if (x.style.display === 'none') {"
  echo "          x.style.display = 'block';"
  echo "      } else {"
  echo "          x.style.display = 'none';"
  echo "      }"
  echo "  }"
  echo "</script>"
  echo "  <meta name='viewport' content='width=device-width, initial-scale=1.0'>"
  echo "<link rel='stylesheet' href='/css/ap_config_login.css'>"
  echo "</head><body>"
  echo "<main class='container'>"
  echo "  <div class='login-card'>"
  echo "    <h1>システム設定</h1>"
  echo "    <p><font color=red>パスワードが違います。</font></p>"
  echo "    <form method='post'>"
  echo "      <input type='password' name='auth' placeholder='パスワード'>"
  echo "      <button type='submit' name='login'>ログイン</button>"
  echo "    </form>"
  echo "    <footer>"
  echo "      &copy; 2026 e-POST Inc. All rights reserved."
  echo "    </footer>"
  echo "  </div>"
  echo "  <div class='login-card'>"
  echo "    <h1>チャットユーザ作成</h1>"
  echo "    <p><br/></p>"
  echo "<a href=/autouser/><img src=/img/chat-icon.gif title='チャットユーザ作成' width=128></a>"
  echo "    <footer>"
  echo "<br/>"
  echo "    </footer>"
  echo "  </div>"
  echo "  <div class='login-card'>"
  echo "    <h1>メールサーバ詳細設定</h1>"
  echo "    <p><br/></p>"
  echo "<a href=/epms/><img src=/img/post-icon.gif title='メールサーバ詳細設定' width=128></a>"
  echo "    <footer>"
  echo "<br/>"
  echo "    </footer>"
  echo "  </div>"
  echo "  <div class='login-card2'>"
  echo "    <center><h1>システム情報</h1></center>"
  echo "    <p><br/></p>"
  echo "<center><img src=/img/sysinfo-icon.gif title='システム情報' width=128 border=0 onclick=toggleVisibility('msg')></center><p id=msg style=display:none;>"
echo "<b>Bord:</b><br/>"
echo "$(cat /proc/device-tree/model)<br/>"
echo "<b>OS:</b><br/>"
echo "$(lsb_release -a)<br/>"
echo "<b>MEM:</b><br/>"
echo "$(df)"
echo "<b>Web Service:</b><br/>"
echo "$(ps ax | grep apache | head -n 4)<br/>"
echo "<b>Mail Service:</b><br/>"
echo "$(ps ax | grep epst | head -n 4)<br/>"
echo "<b>Network:</b><br/>"
echo "$(ip a show)<br/>"
echo "<b>Routing:</b><br/>"
echo "$(ip route)<br/>"
echo "<b>NAT:</b><br/>"
echo "$(sudo iptables -t nat -L -n -v)<br/>"
echo "<b>Pwoer throttled:</b><br/>"
echo "$(sudo vcgencmd get_throttled)<br/>"
echo "<b>CPU Temperature:</b><br/>"
echo "$(($(cat /sys/class/thermal/thermal_zone0/temp)/1000))°C<br/></p>"
  echo "    <footer>"
  echo "<br/>"
  echo "    </footer>"
  echo "  </div>"
  echo "</main>"
  echo "</body></html>"
  exit 0
fi

# NATルール設定（iptables）
sudo iptables -t nat -F
sudo iptables -F

if [ -n "$SYS_ACTION" ] && [ "$AP_NAT_ENABLED" = "yes" ]; then
  sudo iptables -t nat -A POSTROUTING -o "$WAN_IF" -j MASQUERADE
  sudo iptables -A FORWARD -i "$WAN_IF" -o "$IFACE" -m state --state RELATED,ESTABLISHED -j ACCEPT
  sudo iptables -A FORWARD -i "$IFACE" -o "$WAN_IF" -j ACCEPT
  sudo iptables -t nat -A POSTROUTING -o "$WLAN_IF" -j MASQUERADE
  sudo iptables -A FORWARD -i "$WLAN_IF" -o "$IFACE" -m state --state RELATED,ESTABLISHED -j ACCEPT
  sudo iptables -A FORWARD -i "$IFACE" -o "$WAN_IF" -j ACCEPT
fi
sudo netfilter-persistent save

# WAN設定
if [ -n "$WAN_IF" ] && [ -n "$WAN_IP" ] && [ -n "$WAN_NETMASK" ]; then
  ifconfig "$WAN_IF" "$WAN_IP" netmask "$WAN_NETMASK"
fi

if [ -n "$WLAN_IF" ] && [ -n "$WLAN_IP" ] && [ -n "$WLAN_NETMASK" ]; then
  ifconfig "$WLAN_IF" "$WLAN_IP" netmask "$WLAN_NETMASK"
fi

# NATルール設定（iptables）
iptables -t nat -F
iptables -F
iptables -t nat -A POSTROUTING -o "$WAN_IF" -j MASQUERADE
iptables -A FORWARD -i "$WAN_IF" -o "$IFACE" -m state --state RELATED,ESTABLISHED -j ACCEPT
iptables -A FORWARD -i "$IFACE" -o "$WAN_IF" -j ACCEPT
iptables -t nat -A POSTROUTING -o "$WLAN_IF" -j MASQUERADE
iptables -A FORWARD -i "$WLAN_IF" -o "$IFACE" -m state --state RELATED,ESTABLISHED -j ACCEPT
iptables -A FORWARD -i "$IFACE" -o "$WAN_IF" -j ACCEPT

# 設定ファイルパス
SSID_PASSWORD_TXT="ssid_passwords.txt"
SSID_PASSWORD_TMP="ssid_passwords.tmp"
HOSTAPD_CONF="/etc/hostapd/hostapd.conf"
DNSMASQ_CONF="/etc/dnsmasq.conf"
NETPLAN_CONF="/etc/netplan/50-cloud-init.yaml"
SYSCTL_CONF="/etc/sysctl.conf"
RESOLVED_CONF="/etc/systemd/resolved.conf"
IFACE=$APLAN_IF # "wlx24ec99bfa2d5"
AUTOUSER_HTML="/var/www/html/autouser/index.html"
AUTOUSER_CONF="/usr/lib/cgi-bin/autouser.ini"

AUTOUSER_DOMAIN=$(sudo grep 'id="domain"' "$AUTOUSER_HTML" | sed -n 's/.*value="\([^"]*\)".*/\1/p')
AUTOUSER_PASSWORD=$(sudo grep -A 1 'accesscode'  "$AUTOUSER_CONF" | tail -n 1)
AUTOUSER_SMTP_ADDR=$(sudo grep 'sh=' "$AUTOUSER_CONF" | cut -d'=' -f2)
AUTOUSER_SMTP_PORT=$(sudo grep 'sp=' "$AUTOUSER_CONF" | cut -d'=' -f2)
AUTOUSER_SMTP_ENABLED=$(sudo grep 'ss=' "$AUTOUSER_CONF" |  cut -d'=' -f2)
AUTOUSER_IMAP_ADDR=$(sudo grep 'ih=' "$AUTOUSER_CONF" |  cut -d'=' -f2)
AUTOUSER_IMAP_PORT=$(sudo grep 'ip=' "$AUTOUSER_CONF" |  cut -d'=' -f2)
AUTOUSER_IMAP_ENABLED=$(sudo grep 'is=' "$AUTOUSER_CONF" |  cut -d'=' -f2)
#echo "<pre>AUTOUSER_DOMAIN=$AUTOUSER_DOMAIN</pre>"
#echo "<pre>AUTOUSER_PASSWORD=$AUTOUSER_PASSWORD</pre>"
#echo "<pre>AUTOUSER_SMTP_ADDR=$AUTOUSER_SMTP_ADDR</pre>"

NEW_AUTOUSER_DOMAIN=$(echo "$POST_DATA" | sed -n 's/.*autouser_domain=\([^&]*\).*/\1/p')
NEW_AUTOUSER_PASSWORD=$(echo "$POST_DATA" | sed -n 's/.*autouser_password=\([^&]*\).*/\1/p')
NEW_AUTOUSER_SMTP_ADDR=$(echo "$POST_DATA" | sed -n 's/.*autouser_smtp_addr=\([^&]*\).*/\1/p')
NEW_AUTOUSER_SMTP_PORT=$(echo "$POST_DATA" | sed -n 's/.*autouser_smtp_port=\([^&]*\).*/\1/p')
NEW_AUTOUSER_SMTP_ENABLED=$(echo "$POST_DATA" | sed -n 's/.*autouser_smtp_enabled=\([^&]*\).*/\1/p')
NEW_AUTOUSER_IMAP_ADDR=$(echo "$POST_DATA" | sed -n 's/.*autouser_imap_addr=\([^&]*\).*/\1/p')
NEW_AUTOUSER_IMAP_PORT=$(echo "$POST_DATA" | sed -n 's/.*autouser_imap_port=\([^&]*\).*/\1/p')
NEW_AUTOUSER_IMAP_ENABLED=$(echo "$POST_DATA" | sed -n 's/.*autouser_imap_enabled=\([^&]*\).*/\1/p')

#CURRENT_WAN_DHCP=$(/usr/bin/sudo grep -A5 '$WAN_IF:' "/etc/netplan/50-cloud-init.yaml" | grep 'dhcp4:' | cut -d':' -f2 | sed 's/^ *//')
CURRENT_WAN_DHCP=$(sudo awk -v iface="$WAN_IF" '$0 ~ iface ":" {in_iface=1; next} in_iface && /dhcp4:/ { print $2; exit }' $NETPLAN_CONF)
CURRENT_IP=$(ip addr show "$IFACE" | grep 'inet ' | awk '{print $2}' | cut -d '/' -f1 | head -n1)
CURRENT_WAN_ROUTE=$(sudo awk -v iface="$WAN_IF" ' $0 ~ iface ":" {in_iface=1; next} in_iface && /^[[:space:]]+routes:/ {in_routes=1; next} in_routes && /via:/ { print $2; exit }' "$NETPLAN_CONF")
CURRENT_WAN_DNS=$(sudo awk -v iface="$WAN_IF" ' $0 ~ iface ":" {in_iface=1; next} in_iface && /^[[:space:]]+nameservers:/ {in_routes=1; next} in_routes && /addresses:/ { print $2; exit }' "$NETPLAN_CONF")

#CURRENT_WLAN_DHCP=$(/usr/bin/sudo grep -A5 '$WLAN_IF:' "/etc/netplan/50-cloud-init.yaml" | grep 'dhcp4:' | cut -d':' -f2 | sed 's/^ *//')
CURRENT_WLAN_DHCP=$(sudo awk -v iface="$WLAN_IF" '$0 ~ iface ":" {in_iface=1; next} in_iface && /dhcp4:/ { print $2; exit }' $NETPLAN_CONF)
CURRENT_WLAN_SSID=$(/usr/bin/sudo grep -A1 'access-points:' "$NETPLAN_CONF" | grep -v 'access-points:' | sed -n 's/^[[:space:]]*"\([^"]*\)":.*/\1/p' | head -n1)
CURRENT_WLAN_PASSWORD=$(/usr/bin/sudo grep -A2 'access-points:' "$NETPLAN_CONF" | grep 'password:' | sed -n 's/^[[:space:]]*password:[[:space:]]*"\([^"]*\)"/\1/p' | head -n1)
CURRENT_WLAN_ROUTE=$(sudo awk -v iface="$WLAN_IF" ' $0 ~ iface ":" {in_iface=1; next} in_iface && /^[[:space:]]+routes:/ {in_routes=1; next} in_routes && /via:/ { print $2; exit }' "$NETPLAN_CONF")
CURRENT_WLAN_DNS=$(sudo awk -v iface="$WLAN_IF" ' $0 ~ iface ":" {in_iface=1; next} in_iface && /^[[:space:]]+nameservers:/ {in_routes=1; next} in_routes && /addresses:/ { print $2; exit }' "$NETPLAN_CONF")


if [ -n "$SYS_ACTION" ] && [ -n "$NEW_AUTOUSER_DOMAIN" ]; then
#echo "<pre>AP_IP=$AP_IP</pre>"
#echo "<pre>NEW_AUTOUSER_DOMAIN=$NEW_AUTOUSER_DOMAIN</pre>"
sudo /usr/local/bin/add_hosts.sh "$AP_IP" "$NEW_AUTOUSER_DOMAIN"
fi

# 設定更新処理
if [ -n "$SYS_ACTION" ] && [ -n "$SSH_ENABLED" ]; then
#echo "<pre>AP_DHCP_ENABLED=[$AP_DHCP_ENABLED]</pre>"
  if [ "$SSH_ENABLED" = "yes" ]; then
#echo "<pre>enable</pre>"
    sudo systemctl enable ssh.socket
    sudo systemctl start ssh.socket
#    sudo systemctl enable ssh
#    sudo systemctl start ssh
  else
#echo "<pre>disable</pre>"
    sudo systemctl disable ssh.socket
    sudo systemctl stop ssh.socket
    sudo systemctl stop ssh.service
#    sudo systemctl stop ssh
#    sudo systemctl disable ssh
  fi
  DISPLAY_SSH_ENABLED=$(sudo systemctl status ssh | grep Active | awk '{print $2}' | head -n 1)
fi

if [ -n "$SYS_ACTION" ] && [ -n "$NAMED_ENABLED" ]; then
#echo "<pre>AP_DHCP_ENABLED=[$AP_DHCP_ENABLED]</pre>"
  if [ "$NAMED_ENABLED" = "yes" ]; then
#echo "<pre>enable</pre>"
    sudo systemctl enable named
    sudo systemctl start named
  else
#echo "<pre>disable</pre>"
    sudo systemctl stop named
    sudo systemctl disable named
  fi
  DISPLAY_NAMED_ENABLED=$(sudo systemctl status named | grep Active | awk '{print $2}' | head -n 1)
fi

if [ -n "$SYS_ACTION" ] && [ -n "$AP_DHCP_ENABLED" ]; then
#echo "<pre>AP_DHCP_ENABLED=[$AP_DHCP_ENABLED]</pre>"
  if [ "$AP_DHCP_ENABLED" = "yes" ]; then
#echo "<pre>enable</pre>"
    sudo systemctl enable dnsmasq
    sudo systemctl start dnsmasq
  else
#echo "<pre>disable</pre>"
    sudo systemctl stop dnsmasq
    sudo systemctl disable dnsmasq
  fi
  DISPLAY_AP_DHCP_ENABLED=$(sudo systemctl status dnsmasq | grep Active | awk '{print $2}' | head -n 1)
fi

STORED_PASSWORD=$(grep '^admin_password=' "$CONFIG_FILE" | cut -d '=' -f2)
# echo "<pre>ADMIN_PASSWORD=[$ADMIN_PASSWORD]</pre>"
# echo "<pre>STORED_PASSWORD=[$STORED_PASSWORD]</pre>"
# echo "<pre>SYS_ACTION: $SYS_ACTION</pre>"
if [ -n "$SYS_ACTION" ] && [ -n "$ADMIN_PASSWORD" ]; then
# echo "<pre>ADMIN_PASSWORD=[$ADMIN_PASSWORD]</pre>"
# echo "<pre>STORED_PASSWORD=[$STORED_PASSWORD]</pre>"
  if [ "$STORED_PASSWORD" != "$ADMIN_PASSWORD" ]; then
cat <<EOF | sudo tee "$CONFIG_FILE" > /dev/null
admin_password=$ADMIN_PASSWORD
EOF

STORED_PASSWORD=$ADMIN_PASSWORD
printf "%s" "$ADMIN_PASSWORD" > /var/spool/epms/reg/epost/ims/secur/SysPassword.0
echo "raspi5:$ADMIN_PASSWORD" | sudo /usr/sbin/chpasswd
  fi
fi

if [ -n "$NEW_AUTOUSER_DOMAIN" ]; then
  if [ "$AUTOUSER_DOMAIN" != "$NEW_AUTOUSER_DOMAIN" ]; then
sudo sed -i -E 's/(<input[^>]*id="domain"[^>]*value=")[^"]*(")/\1'"$NEW_AUTOUSER_DOMAIN"'\2/' "$AUTOUSER_HTML"
	AUTOUSER_DOMAIN=$NEW_AUTOUSER_DOMAIN
  fi
fi

if [ -n "$SYS_ACTION" ] && [ -n "$NEW_AUTOUSER_PASSWORD" ]; then
  if [ "$AUTOUSER_PASSWORD" != "$NEW_AUTOUSER_PASSWORD" ] ||
     [ "$AUTOUSER_SMTP_ADDR" != "$NEW_AUTOUSER_SMTP_ADDR" ] ||
     [ "$AUTOUSER_SMTP_PORT" != "$NEW_AUTOUSER_SMTP_PORT" ] ||
     [ "$AUTOUSER_SMTP_ENABLED" != "$NEW_AUTOUSER_SMTP_ENABLED" ] ||
     [ "$AUTOUSER_IMAP_ADDR" != "$NEW_AUTOUSER_IMAP_ADDR" ] ||
     [ "$AUTOUSER_IMAP_PORT" != "$NEW_AUTOUSER_IMAP_PORT" ] ||
     [ "$AUTOUSER_IMAP_ENABLED" != "$NEW_AUTOUSER_IMAP_ENABLED" ]; then

sudo cat <<EOF | sudo tee "$AUTOUSER_CONF" > /dev/null
[htmlpath]
/var/www/html/autouser

[accesscode]
$NEW_AUTOUSER_PASSWORD

[profile]
DCLOGIN://
%s@%s
v=1
p=%s
ih=$NEW_AUTOUSER_IMAP_ADDR
ip=$NEW_AUTOUSER_IMAP_PORT
iu=%s
ipw=%s
is=$NEW_AUTOUSER_IMAP_ENABLED
ic=3
sh=$NEW_AUTOUSER_SMTP_ADDR
sp=$NEW_AUTOUSER_SMTP_PORT
su=%s
spw=%s
ss=$NEW_AUTOUSER_SMTP_ENABLED
sc=3
EOF

AUTOUSER_PASSWORD=$(sudo grep -A 1 'accesscode'  "$AUTOUSER_CONF" | tail -n 1)
AUTOUSER_SMTP_ADDR=$(sudo grep 'sh=' "$AUTOUSER_CONF" | cut -d'=' -f2)
AUTOUSER_SMTP_PORT=$(sudo grep 'sp=' "$AUTOUSER_CONF" | cut -d'=' -f2)
AUTOUSER_SMTP_ENABLED=$(sudo grep 'ss=' "$AUTOUSER_CONF" |  cut -d'=' -f2)
AUTOUSER_IMAP_ADDR=$(sudo grep 'ih=' "$AUTOUSER_CONF" |  cut -d'=' -f2)
AUTOUSER_IMAP_PORT=$(sudo grep 'ip=' "$AUTOUSER_CONF" |  cut -d'=' -f2)
AUTOUSER_IMAP_ENABLED=$(sudo grep 'is=' "$AUTOUSER_CONF" |  cut -d'=' -f2)
  fi
fi

if [ -n "$SYS_ACTION" ]; then
# if [ -n "$SYS_ACTION" ] && [ -n "$SSID" ] && [ -n "$PSK" ] && [ -n "$AP_IP" ] && [ -n "$WAN_NETMASK" ] && [ -n "$WLAN_SSID" ] && [ -n "$WLAN_PASSWORD" ]; then
  # hostapd.conf
cat <<EOF | sudo tee "$HOSTAPD_CONF" > /dev/null
interface=$IFACE
driver=nl80211
ssid=$SSID
#hw_mode=g
#channel=6
hw_mode=$AP_HW_MODE
channel=$AP_CHANNEL
ieee80211ax=1
ieee80211ac=1
ieee80211n=1
auth_algs=1
wpa=2
wpa_passphrase=$PSK
wpa_key_mgmt=WPA-PSK
rsn_pairwise=CCMP
EOF

  # dnsmasq.conf
cat <<EOF | sudo tee "$DNSMASQ_CONF" > /dev/null
interface=$IFACE
dhcp-range=$RANGE_START,$RANGE_END,${LEASE_TIME}h
dhcp-option=3,$AP_IP
dhcp-option=6,8.8.8.8,8.8.4.4
log-dhcp
EOF

  # resolved.conf
  sed -i '/^#*DNSStubListener=/d' "$RESOLVED_CONF"
  echo "[Resolve]" >> "$RESOLVED_CONF"
  echo "DNSStubListener=no" >> "$RESOLVED_CONF"

  # netplan
# ETH0_CIDR=$(netmask_to_cidr "$WAN_NETMASK")
# CIDR=$(netmask_to_cidr "$WAN_NETMASK")

#echo "<pre>WAN_DHCP_ENABLED=$WAN_DHCP_ENABLED</pre>"
#echo "<pre>CURRENT_WAN_DHCP_ENABLED=$CURRENT_WAN_DHCP_ENABLED</pre>"
if [ -z "$WAN_DHCP_ENABLED" ]; then
  WAN_DHCP_RESULT=$( [ "$CURRENT_WAN_DHCP_ENABLED" = "yes" ] && echo true || echo no )
else
  WAN_DHCP_RESULT=$( [ "$WAN_DHCP_ENABLED" = "yes" ] && echo true || echo no )
fi
#echo "<pre>WAN_DHCP_RESULT=$WAN_DHCP_RESULT</pre>"
if [ -z "$WLAN_DHCP_ENABLED" ]; then
  WLAN_DHCP_RESULT=$( [ "$CURRENT_WLAN_DHCP_ENABLED" = "yes" ] && echo true || echo no )
else
  WLAN_DHCP_RESULT=$( [ "$WLAN_DHCP_ENABLED" = "yes" ] && echo true || echo no )
fi
# echo "$WLAN_DHCP_RESULT"
# echo "$AP_IP"
# echo "$AP_CIDR_MASK"
# echo "<pre>Running sudo tee...</pre>"
# echo "<pre>IFACE= $IFACE</pre>"
# echo "<pre>AP_IP= $AP_IP</pre>"
{
  echo "network:"
  echo "  version: 2"
  echo "  renderer: networkd"
  echo "  ethernets:"
  echo "    eth0:"
  echo "      dhcp4: $WAN_DHCP_RESULT"
  echo "      optional: true"
  if [ "$WAN_DHCP_RESULT" = "no" ]; then
    echo "      addresses:"
    echo "        - $WAN_IP/$ETH0_CIDR"
    echo "      routes:"
    echo "        - to: default"
    echo "          via: $WAN_ROUTE"
    echo "      nameservers:"
    echo "        addresses: [$(echo "$WAN_DNS" | sed 's/ /, /g')]"
#  else
#    echo "        - /$ETH0_CIDR"
  fi
  if [ -n "$IFACE" ] && [ "$IFACE" != "$WLAN_IF" ]; then
    echo "    $IFACE:"
    echo "      dhcp4: no"
    echo "      optional: true"
    echo "      addresses:"
    echo "        - $AP_IP/$AP_CIDR_MASK"
  fi
#  echo "  wifis:"
  if [ "$WLAN_DHCP_RESULT" = "true" ]; then
  echo "  wifis:"
  fi
  echo "    $WLAN_IF:"
  echo "      dhcp4: $WLAN_DHCP_RESULT"
  if [ "$WLAN_DHCP_RESULT" = "true" ]; then
#    echo "      addresses:"
#    echo "        - $WLAN_IP/$ETH0_CIDR"
#    echo "      nameservers:"
#    echo "        addresses: [$(echo "$WLAN_DNS" | sed 's/ /, /g')]"
#  else
    echo "      access-points:"
    echo "        \"$WLAN_SSID\":"
    echo "          password: \"$WLAN_PASSWORD\""
  fi
  echo "      optional: true"
	} | sudo tee "$NETPLAN_CONF" > /dev/null

# echo "<pre>WLAN_SSID=$WLAN_SSID</pre>"

  # sysctl.conf
  sudo sed -i 's/^#*net.ipv4.ip_forward=.*/net.ipv4.ip_forward=1/' "$SYSCTL_CONF" >/dev/null 2>&1

  # 再起動指示
  sudo systemctl restart hostapd
  sudo systemctl restart dnsmasq
  sudo netplan apply >/dev/null 2>&1
  # netplan apply
  sudo systemctl restart systemd-resolved
#  sysctl -p
  sudo sysctl -p >/dev/null 2>&1

TXT_SSID=$(echo "$QUERY_STRING" | sed -n 's/^.*ap_ssid=\([^&]*\).*$/\1/p' | sed 's/+/ /g; s/%20/ /g')
TXT_PASSWORD=$(echo "$QUERY_STRING" | sed -n 's/^.*wlan_password=\([^&]*\).*$/\1/p' | sed 's/+/ /g; s/%20/ /g')

FILE=$SSID_PASSWORD_TXT
TMP_FILE=$SSID_PASSWORD_TMP
touch "$FILE"
FOUND=0
while IFS=: read -r ssid pw; do
    if [ "$ssid" = "$TXT_SSID" ]; then
        echo "$SSID:$TXT_PASSWORD" >> "$TMP_FILE"
        FOUND=1
    else
        echo "$ssid:$pw" >> "$TMP_FILE"
    fi
done < "$FILE"
if [ "$FOUND" -eq 0 ]; then
    echo "$TXT_SSID:$TXT_PASSWORD" >> "$TMP_FILE"
fi
mv "$TMP_FILE" "$FILE"

fi

# 現在の設定読み込み（簡易）
CURRENT_SSID=$(grep '^ssid=' "$HOSTAPD_CONF" | cut -d '=' -f2)
CURRENT_PSK=$(grep '^wpa_passphrase=' "$HOSTAPD_CONF" | cut -d '=' -f2)
CURRENT_RANGE=$(grep '^dhcp-range=' "$DNSMASQ_CONF" | cut -d '=' -f2 | cut -d ',' -f1,2)
CURRENT_LEASE=$(grep '^dhcp-range=' "$DNSMASQ_CONF" | cut -d ',' -f3 | sed 's/h//')

# CURRENT_WAN_DHCP_ENABLED=$WAN_DHCP_ENABLED
# CURRENT_WLAN_DHCP_ENABLED=$WLAN_DHCP_ENABLED
CURRENT_WLAN_IP=$(ip addr show "$WLAN_IF" | grep 'inet ' | awk '{print $2}' | cut -d '/' -f1)
DISPLAY_WLAN_ROUTE=$(ip route | grep default | grep "$WLAN_IF" | awk '{print $3}')

#echo "<pre>WAN_DHCP_ENABLED=$WAN_DHCP_ENABLED</pre>"
#echo "<pre>CURRENT_WAN_DHCP_ENABLED=$CURRENT_WAN_DHCP_ENABLED</pre>"
if [ -z "$WAN_DHCP_ENABLED" ]; then
  WAN_DHCP_ENABLED=$( [ "$CURRENT_WAN_DHCP_ENABLED" = "yes" ] && echo true || echo no )
fi
if [ -z "$WLAN_DHCP_ENABLED" ]; then
  WLAN_DHCP_ENABLED=$( [ "$CURRENT_WLAN_DHCP_ENABLED" = "yes" ] && echo true || echo no )
fi

#echo "<pre>POST_DATA=$POST_DATA\nWAN_NETMASK=$WAN_NETMASK\nCURRENT_WAN_NETMASK=$CURRENT_WAN_NETMASK</pre>"
#  echo "<html><meta charset=UTF-8 /><body><h2>設定を更新しました</h2><a href='ap_config.cgi'>戻る</a></body></html>"
#  exit 0
CURRENT_WLAN_SSID=$WLAN_SSID
CURRENT_WLAN_PASSWORD=$WLAN_PASSWORD
if [ -z "$SYS_ACTION" ]; then
  sleep 1
else
  if [ "$SYS_ACTION" = "renew" ]; then
    sleep 3
  else
    if [ "$SYS_ACTION" = "msbackup" ]; then
   	  sudo /usr/local/bin/backup_epms.sh --device /dev/mmcblk0 --yes > /tmp/backup.log 2>&1 &
    else
      if [ "$SYS_ACTION" = "msrestore" ]; then
      	sudo /usr/local/bin/restore_epms.sh --device /dev/mmcblk0 --yes > /tmp/restore.log 2>&1 &
      else
        if [ "$SYS_ACTION" = "msinit" ]; then
          sudo bash -c 'cd /home/raspi5/TinyBox && sudo ./reset_epms.sh' > /dev/null 2>&1
        else
          if [ "$SYS_ACTION" = "apinit" ]; then
            sudo cp "$NETPLAN_CONF.init" "$NETPLAN_CONF"
          else
            if [ "$SYS_ACTION" = "off" ]; then
              sudo shutdown -h now
            else
              sudo shutdown -r now
            fi
          fi
        fi
      fi
    fi
  fi
fi

# echo "<pre>CURRENT_WAN_DHCP_RESULT=$CURRENT_WAN_DHCP_RESULT</pre>"
# echo "<pre>CURRENT_WLAN_DHCP_RESULT=$CURRENT_WLAN_DHCP_RESULT</pre>"
# echo "<pre>CURRENT_WLAN_IP=$CURRENT_WLAN_IP</pre>"
# echo "<pre>DISPLAY_WLAN_ROUTE=$DISPLAY_WLAN_ROUTE</pre>"

# echo "<pre>POST_DATA=$POST_DATA\nWAN_NETMASK=$WAN_NETMASK\nCURRENT_WAN_NETMASK=$CURRENT_WAN_NETMASK</pre>"
# echo "<pre>WAN_IP=$WAN_IP</pre>"

# フォーム表示
echo "<html><meta charset=UTF-8 />"
echo "<head>"
echo "<script>function showConfirm() {const result = confirm('この操作を実行しますか？');if (result) {alert('OKが選択されました！');} else {alert('キャンセルが選択されました！');}}"
echo "var ssidPasswords = {"

# JSON形式で出力
awk -F':' '{printf "\"%s\":\"%s\",\n", $1, $2}' $SSID_PASSWORD_TXT | sed '$s/,$//'

echo "};"

# 選択されたSSIDに応じてパスワードを反映
cat << 'EOF'
function updatePassword() {
    var ap_ssid = document.getElementById("ap_ssid").value;
    var password = ssidPasswords[ap_ssid] || "";
    document.getElementById("wlan_password").value = password;
}
function updateChannel() {
    var mode = document.getElementById("hw_mode").value;
    var channelInput = document.getElementById("channel_input");
    if (mode === "a") {
      channelInput.value = "36"; // 5GHz帯の代表的なチャンネル
    } else {
      channelInput.value = "6";  // 2.4GHz帯の代表的なチャンネル
    }
}
function toggleVisibility(className) {
   var x = document.getElementById(className);
   if (x.style.display === 'none') {
     x.style.display = 'block';
   } else {
     x.style.display = 'none';
   } 
}
function Powercontrol(){
  var result = false;
  // confirm('クリック '+document.sysset.sys_action.value);
  if (document.sysset.sys_action.value == 'renew') // 電源オフ
  {
    result = confirm('設定を更新しますか？');
  } else if (document.sysset.sys_action.value == 'off') { // 電源オフ
    result = confirm('電源を切りますか？');
  } else if (document.sysset.sys_action.value == 'reboot') { // 再起動
    result = confirm('再起動を行いますか？\n再起動完了まで(120秒程)お待ちいただき、再びブラウザを開いて確認を行ってください。)');
  } else if (document.sysset.sys_action.value == 'apinit') { // AP初期化
    result = confirm('アクセスポイント設定を初期化しますか？');
  } else if (document.sysset.sys_action.value == 'msinit') { // MS初期化
    result = confirm('メールサーバの設定を初期化しますか？\nメールアカウントとメールデータがすべて全て削除しますか？');
  } else if (document.sysset.sys_action.value == 'msbackup') { // MSデータバックアップ
    result = confirm('メール環境＆アカウントの設定を\nメディア(microSD 又は USBメモリ)に\n複製(バックアアップ)しますか？\n\n実行状態は上部に表示されます。');
  } else if (document.sysset.sys_action.value == 'msrestore') { // MSデータ復元
    result = confirm('メール環境＆アカウントの設定を\nメディア(microSD 又は USBメモリ)から\n復元しますか？\n\n実行状態は上部に表示されます。');
  }
  if(!result) {
　　document.sysset.sys_action.value = ''
    // データを設定
    ele.setAttribute('type', 'hidden');
    ele.setAttribute('name', 'sys_action');
    ele.setAttribute('value', '');    
    document.sysset.appendChild(ele);
  }
}

EOF
echo "</script>"
echo "  <meta name="viewport" content="width=device-width, initial-scale=1.0">"
echo "<link rel=stylesheet href='/css/ap_config_system.css'>"
echo "</head>"
echo "<body>"
#echo "<table border=0><tr><td><a href="/"><img src=/img/logo-mini.gif title='ログアウトする' ></a></td></tr>"
#echo "<tr><td>"
if [ -f "/tmp/backup.log" ]; then	
  if grep -q "✅ バックアップ完了！" "/tmp/backup.log"; then
    echo "✅ 複製（バックアップ）は完了しています！<br/>"
    sudo rm /tmp/backup.log
  else
    echo "⏳ 複製（バックアップ）中…<br/>"
  fi
fi
if [ -f "/tmp/restore.log" ]; then	
  if grep -q "✅ リストア完了！" "/tmp/restore.log"; then
    echo "✅ 復元は完了しています！<br/>"
    sudo rm /tmp/restore.log
  else
    echo "⏳ 復元中…<br/>"
  fi
fi
echo "<header><h1>システム設定</h1></header>"
##echo "<h2>システム設定</h2>"
echo "<form method='post' name="sysset" enctype='application/x-www-form-urlencoded'>"
echo "<main class='container'>"

echo "<div class='card'>"
echo "<h2>ネットワーク設定(1)</h2>"
echo "<p class='item'><span class='label'>Wifi接続:</span> $WLAN_IF / DHCP <select name='wlan_dhcp_enabled'>"
if [ "${CURRENT_WLAN_DHCP_ENABLED:-$CURRENT_WLAN_DHCP}" = "no" ]; then
  echo "<option value='yes'>有効</option><option value='no' selected>無効</option>"
else
  echo "<option value='yes' selected>有効</option><option value='no'>無効</option>"
fi
echo "</select></p>"
SSID_LIST=$(sudo iw dev wlan0 scan | grep 'SSID:' | sed 's/SSID: //' | grep -v '^$' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//' | sort -u)
echo "<p class='item'><span class='label'>SSID:</span> <select name='wlan_ssid' id='wlan_ssid' onchange='updatePassword()'>"
echo "$SSID_LIST" | while IFS= read wlan_ssid; do
    if [ "$wlan_ssid" = "$CURRENT_WLAN_SSID" ]; then
        echo "<option value=\"$wlan_ssid\" selected>$wlan_ssid</option>"
    else
        echo "<option value=\"$wlan_ssid\">$wlan_ssid</option>"
    fi
done
echo "</select></p>"
echo "<p class='item'><span class='label'>パスワード:</span> <input type='text' id='wlan_password' name='wlan_password' value='$CURRENT_WLAN_PASSWORD'></p>"
echo "<p class='item'><span class='label'>IPアドレス:</span> <input type='text' name='wlan_ip' value='$CURRENT_WLAN_IP'></p>"
echo "<p class='item'><span class='label'>ネットマスク:</span> <input type='text' name='wlan_netmask' value='$WLAN_NETMASK'></p>"
echo "<p class='item'><span class='label'>デフォルトルート:</span> <input type='text' name='waln_route' value='${DISPLAY_WLAN_ROUTE:-$CURRENT_WLAN_ROUTE}'></p>"
echo "<p class='item'><span class='label'>ネームサーバ:</span> <input type='text' name='wlan_dns' value='${DISPLAY_WLAN_DNS:-$CURRENT_WLAN_DNS}'></p>"
echo "</div>"

echo "<div class='card'>"
echo "<h2>ネットワーク設定(2)</h2>"
echo "<p class='item'><span class='label'>固定LAN接続:</span> $WAN_IF / DHCP <select name='wan_dhcp_enabled'>"
if [ "${CURRENT_WAN_DHCP_ENABLED:-$CURRENT_WAN_DHCP}" = "no" ]; then
  echo "<option value='yes'>有効</option><option value='no' selected>無効</option>"
else
  echo "<option value='yes' selected>有効</option><option value='no'>無効</option>"
fi
echo "</select></p>"
echo "<p class='item'><span class='label'>IPアドレス:</span> <input type='text' name='wan_ip' value='$CURRENT_WAN_IP'></p>"
echo "<p class='item'><span class='label'>ネットマスク:</span> <input type='text' name='wan_netmask' value='$WAN_NETMASK'></p>"
echo "<p class='item'><span class='label'>デフォルトルート:</span> <input type='text' name='wan_route' value='${DISPLAY_WAN_ROUTE:-$CURRENT_WAN_ROUTE}'></p>"
echo "<p class='item'><span class='label'>ネームサーバ:</span> <input type='text' name='wan_dns' value='${DISPLAY_WAN_DNS:-$CURRENT_WAN_DNS}'></p>"
echo "</div>"

echo "<div class='card'>"
echo "<h2>アクセスポイント($APLAN_IF)設定</h2>"
echo "<p class='item'><span class='label'>SSID:</span> <input type='text' name='ap_ssid' value='$CURRENT_SSID'></p>"
echo "<p class='item'><span class='label'>パスワード:</span> <input type='text' name='ap_psk' value='$CURRENT_PSK'></p>"
echo "<p class='item'><span class='label'>規格(a/g):</span> <select name='ap_hw_mode' id='hw_mode' onchange='updateChannel()'>"
if [ "$AP_HW_MODE" = "a" ]; then
  echo "<option value='g'>g</option><option value='a' selected>a</option>"
else
  echo "<option value='g' selected>g</option><option value='a'>a</option>"
fi
echo "</select></p>"
echo "<p class='item'><span class='label'>チャンネル:</span> <input type='text' id='channel_input' name='ap_channel' value='${AP_CHANNEL:-$CURRENT_AP_CHANNEL}'></p>"
echo "<p class='item'><span class='label'>IPアドレス:</span> <input type='text' name='ap_ip' value='${AP_IP:-$CURRENT_IP}'></p>"
echo "<p class='item'><span class='label'>ネットマスク:</span> <input type='text' name='aplan_netmask' value='$APLAN_NETMASK'></p>"
echo "<p class='item'><span class='label'>DHCPサービス:</span> <select name='ap_dhcp_enabled'>"
if [ "$DISPLAY_AP_DHCP_ENABLED" = "inactive" ]; then
  echo "<option value='yes'>有効</option><option value='no' selected>無効</option>"
else
  echo "<option value='yes' selected>有効</option><option value='no'>無効</option>"
fi
echo "</select></p>"
echo "<p class='item'><span class='label'>DHCP開始:</span> <input type='text' name='range_start' value='$(echo $CURRENT_RANGE | cut -d ',' -f1)'></p>"
echo "<p class='item'><span class='label'>DHCP終了:</span> <input type='text' name='range_end' value='$(echo $CURRENT_RANGE | cut -d ',' -f2)'></p>"
echo "<p class='item'><span class='label'>リース時間(h):</span> <input type='text' name='lease_time' value='$CURRENT_LEASE'></p>"
echo "<p class='item'><span class='label'>NAT有効:</span> <select name='ap_nat_enabled'>"
if [ "$AP_NAT_ENABLED" = "no" ]; then
  echo "<option value='yes'>有効</option><option value='no' selected>無効</option>"
else
  echo "<option value='yes' selected>有効</option><option value='no'>無効</option>"
fi
echo "</select></p>"
echo "</div>"

echo "<div class='card'>"
echo "<h2>システム環境設定</h2>"
echo "<p class='item'><span class='label'>管理者パスワード:</span> <input type='password' name='admin_pw' value='$STORED_PASSWORD'></p>"
echo "<p class='item'><span class='label'>SSHサービス:</span> <select name='ssh_enabled'>"
if [ "$DISPLAY_SSH_ENABLED" = "inactive" ]; then
  echo "<option value='yes'>有効</option><option value='no' selected>無効</option>"
else
  echo "<option value='yes' selected>有効</option><option value='no'>無効</option>"
fi
echo "</select></p>"
echo "</div>"

echo "<div class='card'>"
echo "<h2>メール＆チャット環境設定</h2>"
echo "<p class='item'><span class='label'>チャットドメイン:</span> <input type='text' name='autouser_domain' value='$AUTOUSER_DOMAIN'></p>"
echo "<p class='item'><span class='label'>参加コード:</span> <input type='text' name='autouser_password' value='$AUTOUSER_PASSWORD'></p>"
echo "<p class='item'><span class='label'>SMTPサーバ:</span> <input type='text' name='autouser_smtp_addr' value='$AUTOUSER_SMTP_ADDR'></p>"
echo "<p class='item'><span class='label'>SMTPポート:</span> <input type='text' name='autouser_smtp_port' value='$AUTOUSER_SMTP_PORT'></p>"
echo "<p class='item'><span class='label'>SMTP(STARTLS):</span> <select name='autouser_smtp_enabled'>"
if [ "$AUTOUSER_SMTP_ENABLED" = "plain" ]; then
  echo "<option value=''>有効</option><option value='plain' selected>無効</option>"
else
  echo "<option value='' selected>有効</option><option value='plain'>無効</option>"
fi
echo "</select></p>"
echo "<p class='item'><span class='label'>IMAP4サーバ:</span> <input type='text' name='autouser_imap_addr' value='$AUTOUSER_IMAP_ADDR'></p>"
echo "<p class='item'><span class='label'>IMAP4ポート:</span> <input type='text' name='autouser_imap_port' value='$AUTOUSER_IMAP_PORT'></p>"
echo "<p class='item'><span class='label'>IMAP4(STARTLS):</span> <select name='autouser_imap_enabled'>"
if [ "$AUTOUSER_IMAP_ENABLED" = "plain" ]; then
  echo "<option value=''>有効</option><option value='plain' selected>無効</option>"
else
  echo "<option value='' selected>有効</option><option value='plain'>無効</option>"
fi
echo "</select></p>"
echo "</div>"

echo "</main>"
#echo "<p class='item'><span class='label'>"
echo "<center><input type='hidden' name='auth' value='$INPUT_PASSWORD'><select name='sys_action'><option name='sysaction' value='' selected>再表示</option><option name='sysaction' value='renew'>設定更新</option><option name='sysaction' value='off'>電源オフ</option><option name='sysaction' value='reboot'>再起動</option><option name='sysaction' value='apinit'>AP設定初期化</option><option name='sysaction' value='msinit'>メール環境初期化</option><option name='sysaction' value='msbackup'>複製[メール環境＆アカウント]</option><option name='sysaction' value='msrestore'>復元[メール環境＆アカウント]</option></select><br/>"
echo "<button type='submit' onclick='Powercontrol();'>実行する</button></center>"
echo "</form>"
echo "<form method='post' action='/cgi-bin/set_time.cgi' name='systime' enctype='application/x-www-form-urlencoded'><input type='hidden' name='auth' value='$INPUT_PASSWORD'><button type='submit'>時刻設定</button></form> <button type='submit' onclick=location.href='/';>ログアウト</button> <button type='submit' onclick=toggleVisibility('msg')>システム情報</button><br/>"
echo "<p id=msg style=display:none;>"
echo "<b>Bord:</b><br/>"
echo "$(cat /proc/device-tree/model)<br/>"
echo "<b>OS:</b><br/>"
echo "$(lsb_release -a)<br/>"
echo "<b>MEM:</b><br/>"
echo "$(df)<br/>"
echo "<b>Web Service:</b><br/>"
echo "$(ps ax | grep apache | head -n 4)<br/>"
echo "<b>Mail Service:</b><br/>"
echo "$(ps ax | grep epst | head -n 4)<br/>"
echo "<b>Network:</b><br/>"
echo "$(ip a show)<br/>"
echo "<b>Routing:</b><br/>"
echo "$(ip route)<br/>"
echo "<b>NAT:</b><br/>"
echo "$(sudo iptables -t nat -L -n -v)<br/>"
echo "<b>Pwoer throttled:</b><br/>"
echo "$(sudo vcgencmd get_throttled)<br/>"
echo "<b>CPU Temperature:</b><br/>"
echo "$(($(cat /sys/class/thermal/thermal_zone0/temp)/1000))°C<br/>"
echo "<b>dmesg:</b><br/>"
echo "$(sudo dmesg | tail -n 50)</p><br/>"

echo "<footer>&copy; 2026 e-POST Inc. All rights reserved.</footer>"
echo "</body></html>"

