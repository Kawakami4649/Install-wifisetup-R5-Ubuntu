#!/bin/bash

# TinyBox Network Interface
if [ -f /etc/tinybox/network.conf ]; then
    source /etc/tinybox/network.conf
fi
ETH_IF="${ETH_IF:-eth0}"
WLAN_IF="${WLAN_IF:-wlan0}"

# wlxで始まるインターフェース名を取得
#IFACE=$(ip link | grep -oP 'wlx[0-9a-fA-F]+' | head -n 1)
IFACE=$(ip link | grep -oP ': wlx[0-9a-fA-F]+' | grep -oP 'wlx[0-9a-fA-F]+' | head -n 1)

# インターフェースが見つからなければ終了
if [ -z "$IFACE" ]; then
# echo "wlxインターフェースが見つかりませんでした。"
#  IFACE=$(ip link | grep -oP 'wlan[0-9a-fA-F]+' | head -n 1)
  IFACE=$(ip link | grep -oP '$WLAN_IF' | head -n 1)
# exit 1
fi

echo "検出されたWi-Fiインターフェース: $IFACE"

# hostapd.conf の更新
sed -i "s/^interface=.*/interface=$IFACE/" /etc/hostapd/hostapd.conf

# dnsmasq.conf の更新（例：interface行を更新）
sed -i "s/^interface=.*/interface=$IFACE/" /etc/dnsmasq.conf

# netplan設定ファイルの更新（YAML形式なので注意）
NETPLAN_FILE="/etc/netplan/50-cloud-init.yaml"
WLX_IFACE=$(ip link | grep -oP 'wlx[0-9a-fA-F]+' | head -n 1)

cp "$NETPLAN_FILE" "${NETPLAN_FILE}.bak"
TMP_FILE=$(mktemp)

if [[ -n "$WLX_IFACE" ]]; then
  echo "検出された wlx インターフェース: $WLX_IFACE"

  # すでに wlx...: が存在するか確認
  if grep -q "^[[:space:]]*$WLX_IFACE:" "$NETPLAN_FILE"; then
    echo "すでに $WLX_IFACE の設定が存在しています。重複追加はしません。"
    cp "$NETPLAN_FILE" "$TMP_FILE"
  else
    # wlan0: を wlx...: に置換
    awk -v iface="$WLX_IFACE" '
      BEGIN {copy=0}
      /^ *$WLAN_IF:/ {
        copy=1
        print "    " iface ":"
        next
      }
      copy && /^[[:space:]]+[a-zA-Z0-9_]+:/ {copy=0}
      copy && /^[^[:space:]]/ {copy=0}
      copy {print; next}
      {print}
    ' "$NETPLAN_FILE" > "$TMP_FILE"
  fi

  # 末尾に wlan0: の固定設定がなければ追加
  if ! grep -q "^    $WLAN_IF:$" "$TMP_FILE"; then
    cat <<EOF >> "$TMP_FILE"
    $WLAN_IF:
      dhcp4: true
      optional: true
EOF
  fi

else
  echo "wlx インターフェースが見つかりません。"

  # wlx...: を wlan0: に置換
  awk '
    BEGIN {in_wlx=0}
    /^ *wlx[0-9a-fA-F]+:/ {
      sub(/^ *wlx[0-9a-fA-F]+:/, "    $WAN_IF:")
      in_wlx=1
      print
      next
    }
    in_wlx && /^[[:space:]]+[a-zA-Z0-9_]+:/ {in_wlx=0}
    in_wlx && /^[^[:space:]]/ {in_wlx=0}
    in_wlx {print; next}
    {print}
  ' "$NETPLAN_FILE" > "$TMP_FILE"

  # 末尾3行が wlan0: + 固定2行なら削除
  if tail -n 3 "$TMP_FILE" | grep -qE '^    $WLAN_IF:$'; then
    head -n -3 "$TMP_FILE" > "${TMP_FILE}.cleaned"
    mv "${TMP_FILE}.cleaned" "$TMP_FILE"
  fi
fi

mv "$TMP_FILE" "$NETPLAN_FILE"
echo "修正完了: $NETPLAN_FILE"

# パーミッション修正（警告回避）
chmod 600 "$NETPLAN_FILE"

# iptablesルールの更新
IPTABLES_FILE="/etc/iptables/rules.v4"
if grep -q "wlx" "$IPTABLES_FILE"; then
  echo "iptablesルール内のインターフェース名を更新中..."
  sudo cp "$IPTABLES_FILE" "${IPTABLES_FILE}.bak"
  sudo sed -i "s/wlx[0-9a-fA-F]*/$IFACE/g" "$IPTABLES_FILE"
else
  if grep -q "$WLAN_IF" "$IPTABLES_FILE"; then
    echo "iptablesルール内のインターフェース名を更新中..."
    sudo cp "$IPTABLES_FILE" "${IPTABLES_FILE}.bak"
    sudo sed -i "s/wlan[0-9a-fA-F]*/$WLAN_IF/$IFACE/g" "$IPTABLES_FILE"
  else
    echo "注意: $IPTABLES_FILE に wlx インターフェースの記述が見つかりませんでした。"
  fi
fi

# netplanの再適用（必要に応じて）
netplan apply

echo "設定ファイルを更新しました。"

