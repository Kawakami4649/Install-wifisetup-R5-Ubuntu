#!/bin/sh

echo "Content-type: text/html"
echo ""

CONFIG_FILE="./ap_config.ini"
STORED_PASSWORD=$(grep '^admin_password=' "$CONFIG_FILE" | cut -d '=' -f2)

read POST_DATA

INPUT_PASSWORD=$(echo "$POST_DATA" | sed -n 's/.*auth=\([^&]*\).*/\1/p')

# datetime=2025-12-17T06%3A30 を取り出す
RAW_DATETIME=$(echo "$POST_DATA" | sed -n 's/^.*datetime=\([^&]*\).*$/\1/p')

# URLデコード（%3A → : など）
url_decode() {
  echo "$1" | sed 's/+/ /g;s/%/\\x/g;' | xargs -0 printf "%b"
}

DECODED_DATETIME=$(url_decode "$RAW_DATETIME")

echo "<html><head><meta charset='UTF-8'><title>システム時刻設定</title>"
echo "  <meta name="viewport" content="width=device-width, initial-scale=1.0">"
echo "<link rel=stylesheet href='/css/ap_config_system.css'>"

echo "</head><body>"

#echo "<pre>INPUT_PASSWORD: $INPUT_PASSWORD</pre>"
#echo "<pre>STORED_PASSWORD: $STORED_PASSWORD</pre>"

if [ "$INPUT_PASSWORD" != "$STORED_PASSWORD" ]; then
    echo "<p>システム設定から操作してください。</p>"
    echo "<button type='submit' onclick=location.href='/';>戻る</button></body></html>"
else
  if [ -n "$DECODED_DATETIME" ]; then
    sudo date -s "$DECODED_DATETIME" > /dev/null 2>&1
    if [ $? -eq 0 ]; then
      echo "<p>時刻を <strong>$DECODED_DATETIME</strong> に設定しました。</p>"
    else
      echo "<p>時刻の設定に失敗しました。</p>"
    fi
  else
    echo "<p>システム時刻を入力してください。</p>"
  fi

NOW=$(date +"%Y-%m-%dT%H:%M:%S")

echo "<div class='card'>"
echo "<h2>時刻設定</h2>"
echo "<form method='post'>"
echo "  <label for='datetime'>新しい日時（例: 2025-12-17T06:30:45）:</label><br>"
echo "  <input type='datetime-local' id='datetime' name='datetime' value='$NOW' step='1'>"
echo "  <input type='hidden' name='auth' value='$INPUT_PASSWORD'>"
echo "  <input type='submit' value='設定'></form></div><br/><form method='post' action='/cgi-bin/ap_config.cgi' name='systime' enctype='application/x-www-form-urlencoded'><input type='hidden' name='auth' value='$INPUT_PASSWORD'><button type='submit' >戻る</button></body></html>"
fi

