#!/bin/sh

NEW_IP="$1"
HOSTNAME="$2"
HOSTS_FILE="/etc/hosts"
TMP_FILE=$(mktemp)

cp -p "$HOSTS_FILE" "${HOSTS_FILE}.bak"

FOUND=0
while IFS= read -r line; do
  case "$line" in
    *"$HOSTNAME")
      echo "$NEW_IP $HOSTNAME" >> "$TMP_FILE"
      FOUND=1
      ;;
    *)
      echo "$line" >> "$TMP_FILE"
      ;;
  esac
done < "$HOSTS_FILE"

if [ "$FOUND" -eq 0 ]; then
  echo "$NEW_IP $HOSTNAME" >> "$TMP_FILE"
fi

chmod 644 "$TMP_FILE"

mv "$TMP_FILE" "$HOSTS_FILE"

